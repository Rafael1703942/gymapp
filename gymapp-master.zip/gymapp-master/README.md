# gymapp

# Nome do projeto 

- GYMAPP

# Descrição 

- Está aplicação será construida de forma simples em que objetivo principal 
será atribuir um plano de treino através dos dados que irá pedir ao utilizador que neste caso será o peso da mesma e altura.
Com estes dados poderá ser calculado o IMC (indíce de massa corporal) que será uma ferramenta necessária para ser atribuido o plano de treino.

IMC formula = PESO / Altura * Altura

- Componentes do projeto 
(irá ser alterado pois o design/layout ainda não foi criado)

Textviews , labels , buttons , images ....

- O que faz cada componente

terá pelo menos 3 ecras
1 ecra terá apenas uma imagem ao carregar no botão "entrar" entra no 2 ecra da aplicação
2 ecra pedirá o peso do utilizador e a Altura , terá um botão chamado "calculo" onde irá ser efetuado a conta através desta formula IMC formula = PESO / Altura * Altura e terá um campo onde irá indicar a média calculada , e ainda terá outro botão que se irá chamar "Plano" que irá para o ecrã 3 , ainda terá um botão de fechar
3 ecra irá apenas indicar um plano de treino consuante a média calculada no ecrã 2 , ainda terá um botão de voltar atrás e um de fechar 

# como executar : dependências 

a unica dependencia será que os campos do ecrã 2 têm que ser preenchidos para conseguir efetuar um plano de treino que irá aparecer no ecrã 3

# Exemplos de uso 
(sequencia irá ser alterada)
![tittle](imagem/cobra.jpg)

 