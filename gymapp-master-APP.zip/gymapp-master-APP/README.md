﻿# gymapp Rafael

# Nome do projeto 

- GYMAPP

# Descrição 

- Está aplicação será construida de forma simples em que objetivo principal 
será atribuir um plano de treino através dos dados que irá pedir ao utilizador que neste caso será o peso da mesma e altura.
Com estes dados poderá ser calculado o IMC (indíce de massa corporal) que será uma ferramenta necessária para ser atribuido o plano de treino.

IMC formula = PESO / Altura * Altura

- Componentes do projeto 

- LinearLayout
- ImageView
- Textviews 
- Buttons
- PlainTexts

- O que faz cada componente

- Textviews 
- Buttons
- PlainTexts

Tem cerca de 2 ecrãs a aplicação :
1º Ecra terá apenas uma imagem e um botão que ao carregar no "entrar" vai para o segundo ecrã da aplicação
2º Ecra pedirá o Nome o peso e a altura do utilizador através de uma PlainText, terá um botão chamado "Calcular IMC" onde irá ser efetuado a conta através desta formula 
IMC formula = PESO / Altura * Altura e terá uma TextView campo onde irá indicar a média calculada , e ainda terá outro botão que se chama "Plano de Treino" que irá através da média calculada (IMC) , 
irá indicar um plano de treino numa Textview.


# como executar : dependências 

A unica dependencia será que os campos do ecrã 2 têm que ser preenchidos para conseguir efetuar o calculo do IMC e o plano de treino.


# Exemplos de uso 

![Página inicial 1º ecrã](imagem/Login.jpg)

![Página da calculadora do IMC 2º ecrã](imagem/CalculadoraIMC.jpg)

 