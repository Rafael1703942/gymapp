package com.example.gymapp;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Ecra2 extends AppCompatActivity {


    EditText txpeso, txaltura;
    Button btCalcular;
    TextView txIMC, txResultado, txTreino;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ecra2);

        txpeso = (EditText) findViewById(R.id.peso);
        txaltura = (EditText) findViewById(R.id.altura);
    }

    public void calculateButton(View view) { //onclick (View view)
        EditText nome = (EditText) findViewById(R.id.nome);
        EditText altura = (EditText) findViewById(R.id.altura);
        EditText peso = (EditText) findViewById(R.id.peso);

        double dpeso, daltura, dimc;
        String SMensagem = null;
        String textViewPlano = null;
        double ddpeso = Double.parseDouble(txpeso.getText().toString());
        double ddaltura = Double.parseDouble(txaltura.getText().toString());

        try {
            dimc = ddpeso / (ddaltura * ddaltura);
            if (dimc < 16)
                SMensagem = "magreza severa";
            else if (dimc < 17)
                SMensagem = "magreza moderada";
            else if (dimc < 18.5)
                SMensagem = "magreza leve";
            else if (dimc < 25)
                SMensagem = "peso normal";
            else if (dimc < 30)
                SMensagem = "Sobrepeso";
            else if (dimc < 35)
                SMensagem = "Obesidade classe I";
            else if (dimc < 40)
                SMensagem = "Obesidade classe II";

            else if (dimc > 50)
                SMensagem = "Obesidade classe III";

            txIMC.setText(String.valueOf(dimc));
            txResultado.setText(SMensagem);

        } catch (Exception e) {

        }
    }

        public void calcbutton(View view){ //onclick (View view)
            EditText nomee = (EditText) findViewById(R.id.nome);
            EditText alturaa = (EditText) findViewById(R.id.altura);
            EditText pesoo = (EditText) findViewById(R.id.peso);

            double ddpeso, ddaltura, ddimc;
            String textViewPlano1 = null;
            double dddpeso = Double.parseDouble(txpeso.getText().toString());
            double dddaltura = Double.parseDouble(txaltura.getText().toString());

            try {

                ddimc = dddpeso / (dddaltura * dddaltura);
                if (ddimc < 16)
                    textViewPlano1 = "Deverá fazer um dieta com mais calorias diárias pois encontra-se a baixo do peso normal";
                else if (ddimc < 17)
                    textViewPlano1 = "Deverá fazer um dieta com mais calorias diárias pois encontra-se a baixo do peso normal se possivel adicionar um pouco de musclação a sua rotina";
                else if (ddimc < 18.5)
                    textViewPlano1 = "Deverá fazer um dieta equilibrada na calorias pois encontra-se um pouco a baixo do peso normal se possivel adicionar um pouco de musclação a sua rotina";
                else if (ddimc < 25)
                    textViewPlano1 = "Deverá fazer um dieta equilibrada pois o seu peso é normal se possivel adicionar um pouco de musclação a sua rotina";
                else if (ddimc < 30)
                    textViewPlano1 = "Deverá fazer um dieta equilibrada pois o seu peso está um pouco alto, se possivel adicionar um pouco de musclação e ainda correr seria essencial na sua rotina";
                else if (ddimc < 35)
                    textViewPlano1 = "Deverá fazer um dieta equilibrada pois o seu peso está um pouco alto, se possivel adicionar um pouco de musclação e ainda correr seria essencial na sua rotina";
                else if (ddimc < 40)
                    textViewPlano1 = "Deverá fazer um dieta equilibrada pois o seu peso está um bastante alto, se possivel correr seria essencial na sua rotina";
                else if (ddimc > 50)
                    textViewPlano1 = "Deverá fazer um dieta equilibrada pois o seu peso está um bastante alto, se possivel correr seria essencial na sua rotina";

                txIMC.setText(String.valueOf(ddimc));
                txTreino.setText(textViewPlano1);

            } catch (Exception e) {

            }

        }
    }
